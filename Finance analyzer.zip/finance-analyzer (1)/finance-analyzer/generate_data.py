"""
Creates the demo CSV files:
  data/transactions.csv        (your working data)
  data/sample_transactions.csv (copy used by the 'Load sample data' button)
  data/risk_training.csv       (training data for the Decision Tree)
  data/sample_import.csv       (small file to test the CSV import button)
Run:  python generate_data.py
"""
import os
import random
from datetime import date, timedelta

import pandas as pd

from ml_engine import generate_risk_training

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(DATA, exist_ok=True)
rnd = random.Random(7)
END = date.today()                    # data runs up to today
MONTHS_BACK = 5                       # + the current month = 6 months

DESC = {
    "Groceries": ["Big Basket order", "D-Mart groceries", "Local vegetable market", "Reliance Fresh"],
    "Dining": ["Lunch with team", "Zomato order", "Swiggy dinner", "Cafe coffee", "Weekend brunch", "Pizza night"],
    "Transport": ["Uber ride", "Metro card top-up", "Auto fare", "Petrol", "Ola cab"],
    "Shopping": ["Amazon order", "Clothes", "Footwear", "Home decor", "Electronics accessory"],
    "Entertainment": ["Movie tickets", "Concert", "Gaming credits", "Book purchase"],
    "Health": ["Pharmacy", "Doctor visit", "Health checkup"],
}


def month_start(offset):
    y, m = END.year, END.month - offset
    while m <= 0:
        m += 12
        y -= 1
    return date(y, m, 1)


rows = []


def add(d, desc, cat, typ, amt):
    if d <= END:
        rows.append({"date": d.isoformat(), "description": desc, "category": cat,
                     "type": typ, "amount": round(amt, 2)})


for back in range(MONTHS_BACK, -1, -1):
    s = month_start(back)
    heavy = back == 2                      # one deliberately heavy month
    add(s, "Monthly salary", "Salary", "income", 85000)
    if back % 2 == 0:
        add(s + timedelta(days=14), "Freelance project", "Freelance", "income", rnd.choice([9000, 12000, 15000]))
    add(s + timedelta(days=19), "Dividend payout", "Investments", "income", rnd.randint(800, 2200))
    add(s + timedelta(days=2), "House rent", "Housing", "expense", 22000)
    add(s + timedelta(days=7), "Electricity bill", "Utilities", "expense", rnd.randint(1800, 3200))
    add(s + timedelta(days=9), "Broadband", "Utilities", "expense", 999)
    add(s + timedelta(days=9), "Mobile recharge", "Utilities", "expense", 599)
    add(s + timedelta(days=4), "Netflix", "Subscriptions", "expense", 649)
    add(s + timedelta(days=4), "Spotify", "Subscriptions", "expense", 119)
    add(s + timedelta(days=5), "Gym membership", "Health", "expense", 1500)
    for w in range(5):
        add(s + timedelta(days=w * 6 + rnd.randint(0, 2)), rnd.choice(DESC["Groceries"]), "Groceries", "expense", rnd.randint(1300, 3200))
    for _ in range(rnd.randint(8, 12) + (6 if heavy else 0)):
        add(s + timedelta(days=rnd.randint(0, 28)), rnd.choice(DESC["Dining"]), "Dining", "expense", rnd.randint(220, 1900))
    for _ in range(rnd.randint(10, 14)):
        add(s + timedelta(days=rnd.randint(0, 28)), rnd.choice(DESC["Transport"]), "Transport", "expense", rnd.randint(80, 650))
    add(s + timedelta(days=11), "Fuel top-up", "Transport", "expense", 2500)
    for _ in range(rnd.randint(2, 4) + (3 if heavy else 0)):
        add(s + timedelta(days=rnd.randint(0, 28)), rnd.choice(DESC["Shopping"]), "Shopping", "expense", rnd.randint(900, 6500) * (2 if heavy else 1))
    for _ in range(rnd.randint(2, 4)):
        add(s + timedelta(days=rnd.randint(0, 28)), rnd.choice(DESC["Entertainment"]), "Entertainment", "expense", rnd.randint(400, 1600))
    if rnd.random() < 0.6:
        add(s + timedelta(days=rnd.randint(0, 28)), rnd.choice(DESC["Health"]), "Health", "expense", rnd.randint(300, 2500))
    if heavy:
        add(s + timedelta(days=16), "Goa weekend trip", "Travel", "expense", 18500)
    if back == 4:
        add(s + timedelta(days=12), "Online course", "Education", "expense", 3500)

df = pd.DataFrame(rows).sort_values("date").reset_index(drop=True)
df.insert(0, "id", range(1, len(df) + 1))
df.to_csv(os.path.join(DATA, "transactions.csv"), index=False)
df.to_csv(os.path.join(DATA, "sample_transactions.csv"), index=False)

sample_import = pd.DataFrame([
    [END.isoformat(), "Birthday gift for friend", "Shopping", "expense", 2400],
    [END.isoformat(), "Cab to airport", "Transport", "expense", 850],
    [END.isoformat(), "Client payment", "Freelance", "income", 7500],
    [(END - timedelta(days=1)).isoformat(), "Dinner out", "Dining", "expense", 1650],
    [(END - timedelta(days=1)).isoformat(), "Online course", "Education", "expense", 2999],
    [(END - timedelta(days=2)).isoformat(), "Vegetables", "Groceries", "expense", 540],
], columns=["date", "description", "category", "type", "amount"])
sample_import.to_csv(os.path.join(DATA, "sample_import.csv"), index=False)

generate_risk_training(os.path.join(DATA, "risk_training.csv"))
print(f"Created {len(df)} sample transactions plus training and import files in /data")

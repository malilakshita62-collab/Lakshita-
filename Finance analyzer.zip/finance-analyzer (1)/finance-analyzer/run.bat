@echo off
cd /d "%~dp0"
if not exist venv (
  echo Creating virtual environment...
  python -m venv venv
)
call venv\Scripts\activate
pip install -r requirements.txt
if not exist data\transactions.csv python generate_data.py
python app.py
pause

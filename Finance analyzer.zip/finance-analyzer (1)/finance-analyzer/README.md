# PocketPattern - AI Personal Finance & Expense Pattern Analyzer

Flask + Python + HTML/CSS/JavaScript. Data is stored in CSV files (no database).
Machine learning: **K-Means** (spending patterns) and **Decision Tree** (risk rating).

## Run it on Windows (CMD)

1. Install Python 3.10 or newer from https://www.python.org/downloads/
   (tick "Add python.exe to PATH" in the installer).
2. Unzip the project, then open CMD in that folder:
       cd C:\Users\YourName\Downloads\finance-analyzer
3. Create and activate a virtual environment:
       python -m venv venv
       venv\Scripts\activate
4. Install the libraries:
       pip install -r requirements.txt
5. (Optional) Re-create the demo CSV files. This OVERWRITES data\transactions.csv:
       python generate_data.py
6. Start the app:
       python app.py
7. Open http://127.0.0.1:5000 in your browser. Press Ctrl+C in CMD to stop.

Shortcut: double-click `run.bat` to do steps 3-6 automatically.

The page loads Chart.js and the Manrope font from the internet, so stay online.

## How the live updates work

Every action (add, delete, import, load sample, clear) is written to
`data/transactions.csv` and then the page re-reads the CSV and redraws the
dashboard cards, income bar, all charts, history table, monthly page and AI
insights. A transaction added on the Dashboard shows in History straight away,
and deleting it from either place updates every chart.

## Files

| File | Purpose |
|------|---------|
| app.py | Flask server and CSV read/write API |
| ml_engine.py | Monthly stats, K-Means, Decision Tree, suggestions |
| generate_data.py | Builds the demo CSV files |
| templates/index.html | Page layout |
| static/css/style.css | Modern dashboard styling |
| static/js/app.js | Charts, forms, live refresh |
| data/transactions.csv | Your transactions (id,date,description,category,type,amount) |
| data/sample_transactions.csv | Demo data used by "Load sample data" |
| data/risk_training.csv | Training data for the Decision Tree |
| data/sample_import.csv | Small file to try the "Import CSV" button |

## CSV format for importing

Columns: `date,description,category,type,amount` (type is `income` or `expense`,
date is YYYY-MM-DD). Unknown categories become "Other". Duplicates are skipped.

## Change the currency

Edit `CURRENCY = "₹"` at the top of `ml_engine.py`.

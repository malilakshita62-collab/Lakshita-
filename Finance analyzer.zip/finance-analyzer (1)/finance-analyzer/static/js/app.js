
(() => {
  "use strict";
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  let CUR = "₹";
  let STATE = null;          // analysis from /api/state
  let TXS = [];              // every transaction from /api/transactions
  let selectedMonth = "latest";
  let lastAdded = null;
  let reqCounter = 0;
  let prevStats = {};
  const charts = {};
  const nf = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 });
  const money = (n) => (n < 0 ? "-" : "") + CUR + nf.format(Math.round(Math.abs(n)));
  const pct = (x) => Math.round(x * 100) + "%";

  const PALETTE = {
    Housing: "#0B7A75", Groceries: "#3FA34D", Dining: "#F2A33A", Transport: "#3B82C4", Utilities: "#7A8CA5",
    Health: "#E2748B", Shopping: "#6A5ACD", Entertainment: "#C055B8", Travel: "#E2483D", Education: "#2BAFA5",
    Subscriptions: "#9A7B4F", Other: "#A3ABB9", Salary: "#0B7A75", Freelance: "#2BAFA5", Investments: "#3FA34D",
    Gift: "#E2748B", "Other Income": "#7A8CA5",
  };
  const colorOf = (c) => PALETTE[c] || "#A3ABB9";
  const CLUSTER_COLORS = ["#2BAFA5", "#F2A33A", "#6A5ACD"];
  const clusterColor = (rank, total) => CLUSTER_COLORS[total === 2 && rank === 1 ? 2 : rank];

  Chart.defaults.font.family = '"Manrope", system-ui, sans-serif';
  Chart.defaults.color = "#5E677B";
  Chart.defaults.animation.duration = 450;

  /* ---------------- API ---------------- */
  async function api(url, opts) {
    const res = await fetch(url, { cache: "no-store", ...opts });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Something went wrong.");
    return data;
  }

  let lastSig = "";
  async function loadAll(silent) {
    const me = ++reqCounter;
    const [state, txs] = await Promise.all([
      api("/api/state?month=" + encodeURIComponent(selectedMonth)),
      api("/api/transactions"),
    ]);
    if (me !== reqCounter) return;           // a newer request replaced this one
    const sn = $("#syncNote");
    if (sn) sn.textContent = "Synced " + new Date().toLocaleTimeString("en-IN") + " · " + txs.length + " rows in CSV";
    const sig = JSON.stringify([state, txs]);
    if (silent && sig === lastSig) return;   // nothing changed, skip redraw
    lastSig = sig;
    STATE = state; TXS = txs;
    selectedMonth = state.month;
    CUR = state.meta.currency;
    renderAll();
  }

  /* ---------------- toast ---------------- */
  let toastTimer;
  function toast(msg, isError) {
    const t = $("#toast");
    t.textContent = msg;
    t.className = "toast" + (isError ? " error" : "");
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.hidden = true), 3200);
  }

  /* ---------------- navigation ---------------- */
  const TITLES = { dashboard: "Dashboard", transactions: "History", monthly: "Monthly view", insights: "AI insights" };
  function currentPage() {
    const p = location.hash.replace("#", "");
    return TITLES[p] ? p : "dashboard";
  }
  function showPage() {
    const page = currentPage();
    $$(".page").forEach((s) => (s.hidden = s.id !== "page-" + page));
    $$(".nav a").forEach((a) => a.classList.toggle("active", a.dataset.page === page));
    $("#pageTitle").textContent = TITLES[page];
    $(".select-wrap").hidden = page === "transactions" || page === "monthly";
    window.scrollTo(0, 0);
    setTimeout(() => Object.values(charts).forEach((c) => c.resize()), 30);
  }
  window.addEventListener("hashchange", showPage);

  /* ---------------- render everything ---------------- */
  function renderAll() {
    // each part is isolated so one failure can never block the others
    [renderHeader, renderHero, renderCategoryChart, renderDailyChart, renderRecent,
     renderTips, renderHistory, renderMonthly, renderInsights].forEach((fn) => {
      try { fn(); } catch (err) { console.error(fn.name, err); }
    });
  }

  /* Income / spent / saved / savings rate are calculated from the full
     transaction list, so they always match what you see in History. */
  function clientKpis() {
    const m = STATE.month;
    const sum = (rows, type) => rows.filter((t) => t.type === type).reduce((a, t) => a + t.amount, 0);
    const rows = m === "all" ? TXS : TXS.filter((t) => t.date.startsWith(m));
    const income = sum(rows, "income"), expense = sum(rows, "expense");
    let prev = null;
    const i = STATE.months.indexOf(m);
    if (m !== "all" && i > 0) {
      const pm = STATE.months[i - 1];
      const pr = TXS.filter((t) => t.date.startsWith(pm));
      prev = { label: STATE.monthly[i - 1].label, income: sum(pr, "income"), expense: sum(pr, "expense") };
    }
    return {
      income, expense, savings: income - expense,
      savings_rate: income > 0 ? (income - expense) / income : null,
      count: rows.length, avg_daily: expense / Math.max(1, STATE.kpis.days || 1), prev,
    };
  }

  function renderHeader() {
    const sel = $("#monthSelect");
    const opts = ['<option value="all">All time</option>']
      .concat([...STATE.months].reverse().map((m) => {
        const label = STATE.monthly.find((x) => x.month === m).label;
        return `<option value="${m}">${label}</option>`;
      }));
    sel.innerHTML = opts.join("");
    sel.value = STATE.month;
    const k = clientKpis();
    $("#periodSub").textContent = STATE.has_data
      ? `${STATE.period_label} · ${k.count} transaction${k.count === 1 ? "" : "s"}`
      : "Add a transaction to get started";
  }

  /* ---- hero: income split bar + stats ---- */
  function renderHero() {
    const k = clientKpis();
    const bar = $("#segBar"), legend = $("#segLegend");
    const risk = STATE.risk.label;
    const pill = $("#riskPill");
    pill.textContent = "Risk: " + risk;
    pill.className = "risk-pill " + (["Low", "Medium", "High"].includes(risk) ? risk.toLowerCase() : "");

    if (!STATE.has_data || k.expense <= 0 && k.income <= 0) {
      bar.innerHTML = ""; legend.innerHTML = "";
      $("#heroSub").textContent = "Nothing to show yet. Add your income and expenses below.";
    } else {
      const basis = Math.max(k.income, k.expense);
      const top = STATE.categories.slice(0, 5);
      const topSum = top.reduce((a, c) => a + c.amount, 0);
      const other = Math.max(0, k.expense - topSum);
      const segs = top.map((c) => ({ label: c.category, amount: c.amount, color: colorOf(c.category) }));
      if (other > 0) segs.push({ label: "Everything else", amount: other, color: "#A3ABB9" });
      if (k.income > k.expense) segs.push({ label: "Left over", amount: k.income - k.expense, cls: "left" });
      bar.innerHTML = segs.map((s) =>
        `<div class="seg ${s.cls || ""}" style="flex:${s.amount} 1 0;${s.color ? "background:" + s.color : ""}" title="${esc(s.label)}: ${money(s.amount)}"></div>`
      ).join("");
      if (k.expense > k.income && k.income > 0) {
        bar.insertAdjacentHTML("beforeend", `<span class="seg-mark" style="left:${(k.income / basis) * 100}%" title="Income ends here"></span>`);
      }
      legend.innerHTML = segs.map((s) =>
        `<li><i style="${s.color ? "background:" + s.color : "background:repeating-linear-gradient(135deg,#CBEAE6 0 3px,#DCF1EF 3px 6px)"}"></i>${esc(s.label)} <b>${money(s.amount)}</b></li>`
      ).join("");
      $("#heroSub").textContent = k.income <= 0
        ? "No income recorded in this period."
        : k.expense > k.income
          ? `You spent ${money(k.expense - k.income)} more than you earned. The dark marker shows where income ran out.`
          : `You earned ${money(k.income)} and spent ${pct(k.expense / k.income)} of it.`;
    }

    const delta = (cur, prev, upIsGood) => {
      if (!k.prev || !prev) return "";
      const d = (cur - prev) / prev;
      if (Math.abs(d) < 0.005) return `<small>Same as ${esc(k.prev.label)}</small>`;
      const good = upIsGood ? d > 0 : d < 0;
      return `<small class="${good ? "down" : "up"}">${d > 0 ? "▲" : "▼"} ${pct(Math.abs(d))} vs ${esc(k.prev.label)}</small>`;
    };
    const saved = k.savings;
    const vals = {
      Income: money(k.income), Spent: money(k.expense), Saved: money(Math.abs(saved)),
      Rate: k.savings_rate === null ? "–" : pct(k.savings_rate),
    };
    const changed = (key) => (prevStats[key] !== undefined && prevStats[key] !== vals[key] ? " pulse" : "");
    $("#stats").innerHTML = `
      <div class="stat"><dt>Income</dt><dd class="${changed("Income")}">${vals.Income}</dd>${delta(k.income, k.prev && k.prev.income, true)}</div>
      <div class="stat"><dt>Spent</dt><dd class="${changed("Spent")}">${vals.Spent}</dd>${delta(k.expense, k.prev && k.prev.expense, false)}</div>
      <div class="stat"><dt>${saved < 0 ? "Overspent" : "Saved"}</dt><dd class="${(saved < 0 ? "neg" : "") + changed("Saved")}">${vals.Saved}</dd><small>${money(k.avg_daily)} spent per day</small></div>
      <div class="stat"><dt>Savings rate</dt><dd class="${(k.savings_rate !== null && k.savings_rate < 0 ? "neg" : "") + changed("Rate")}">${vals.Rate}</dd><small>of income kept</small></div>`;
    prevStats = vals;
  }

  /* ---- chart helper: create once, then update in place ---- */
  function upsert(key, canvasId, config) {
    if (charts[key]) {
      charts[key].data = config.data;
      charts[key].options = config.options;   // keeps tooltip callbacks fresh
      charts[key].update();
    } else {
      charts[key] = new Chart($("#" + canvasId), config);
    }
  }
  const axisMoney = (v) => CUR + (Math.abs(v) >= 1000 ? nf.format(v / 1000) + "k" : v);

  function renderCategoryChart() {
    const cats = STATE.categories;
    $("#catEmpty").hidden = cats.length > 0;
    $("#chCategory").parentElement.hidden = cats.length === 0;
    if (!cats.length) return;
    upsert("cat", "chCategory", {
      type: "doughnut",
      data: {
        labels: cats.map((c) => c.category),
        datasets: [{ data: cats.map((c) => c.amount), backgroundColor: cats.map((c) => colorOf(c.category)), borderWidth: 2, borderColor: "#fff" }],
      },
      options: {
        maintainAspectRatio: false, cutout: "62%",
        plugins: {
          legend: { position: "right", labels: { boxWidth: 12, boxHeight: 12, usePointStyle: true } },
          tooltip: { callbacks: { label: (c) => ` ${c.label}: ${money(c.parsed)} (${pct(cats[c.dataIndex].share)})` } },
        },
      },
    });
  }

  function renderDailyChart() {
    const d = STATE.daily;
    $("#dailyNote").textContent = d.weekly ? "Weekly totals" : "Bars: per day · Line: running total";
    upsert("daily", "chDaily", {
      type: "bar",
      data: {
        labels: d.labels,
        datasets: [
          { type: "bar", label: d.weekly ? "Per week" : "Per day", data: d.values, backgroundColor: "#0B7A75", borderRadius: 4, yAxisID: "y", order: 2 },
          { type: "line", label: "Running total", data: d.cumulative, borderColor: "#F2A33A", backgroundColor: "#F2A33A", tension: 0.3, pointRadius: 0, borderWidth: 2.5, yAxisID: "y1", order: 1 },
        ],
      },
      options: {
        maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
        scales: {
          x: { grid: { display: false }, ticks: { maxTicksLimit: 8 } },
          y: { beginAtZero: true, ticks: { callback: axisMoney }, grid: { color: "#EEF0F5" } },
          y1: { position: "right", beginAtZero: true, grid: { display: false }, ticks: { callback: axisMoney } },
        },
        plugins: { legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 10 } },
                   tooltip: { callbacks: { label: (c) => ` ${c.dataset.label}: ${money(c.parsed.y)}` } } },
      },
    });
  }

  /* ---- recent activity (with delete) ---- */
  function fmtDate(iso, withYear) {
    const [y, m, d] = iso.split("-").map(Number);
    return new Date(y, m - 1, d).toLocaleDateString("en-IN", { day: "numeric", month: "short", ...(withYear ? { year: "numeric" } : {}) });
  }
  function renderRecent() {
    const list = $("#recentList");
    if (!STATE.recent.length) {
      list.innerHTML = '<li class="empty">No transactions yet. Add your first one on the left.</li>';
      return;
    }
    list.innerHTML = STATE.recent.map((t) => `
      <li class="${t.id === lastAdded ? "flash" : ""}">
        <span class="dot" style="background:${colorOf(t.category)}">${esc(t.category[0])}</span>
        <div class="meta"><strong>${esc(t.description)}</strong><small>${esc(t.category)} · ${fmtDate(t.date)}</small></div>
        <span class="amt ${t.type}">${t.type === "income" ? "+" : "-"}${money(t.amount)}</span>
        <button class="del" data-id="${t.id}" type="button" aria-label="Delete ${esc(t.description)}">Delete</button>
      </li>`).join("");
  }

  /* ---- suggestions ---- */
  const tipHtml = (s) => `<div class="tip ${s.level}"><strong>${esc(s.title)}</strong><p>${esc(s.text)}</p></div>`;
  function renderTips() {
    $("#dashTips").innerHTML = STATE.suggestions.slice(0, 3).map(tipHtml).join("");
    $("#allTips").innerHTML = STATE.suggestions.map(tipHtml).join("");
  }

  /* ---- history table ---- */
  function renderHistory() {
    // filter dropdowns keep their selection while options refresh
    const cat = $("#fCat"), mon = $("#fMonth");
    const catVal = cat.value, monVal = mon.value;
    const allCats = [...new Set(TXS.map((t) => t.category))].sort();
    cat.innerHTML = '<option value="">All categories</option>' + allCats.map((c) => `<option>${esc(c)}</option>`).join("");
    cat.value = allCats.includes(catVal) ? catVal : "";
    mon.innerHTML = '<option value="">All months</option>' + [...STATE.months].reverse()
      .map((m) => `<option value="${m}">${STATE.monthly.find((x) => x.month === m).label}</option>`).join("");
    mon.value = STATE.months.includes(monVal) ? monVal : "";

    const q = $("#fSearch").value.trim().toLowerCase();
    const type = $("#fType").value;
    const rows = TXS.filter((t) =>
      (!type || t.type === type) && (!cat.value || t.category === cat.value) &&
      (!mon.value || t.date.startsWith(mon.value)) &&
      (!q || t.description.toLowerCase().includes(q) || t.category.toLowerCase().includes(q)));
    const shown = rows.slice(0, 400);
    const net = rows.reduce((a, t) => a + (t.type === "income" ? t.amount : -t.amount), 0);
    $("#histCount").textContent = `${rows.length} of ${TXS.length} transactions · net ${money(net)}` + (rows.length > 400 ? " · showing the latest 400" : "");
    $("#histEmpty").hidden = rows.length > 0;
    $("#histBody").innerHTML = shown.map((t) => `
      <tr class="${t.id === lastAdded ? "flash" : ""}">
        <td>${fmtDate(t.date, true)}</td>
        <td>${esc(t.description)}</td>
        <td><span class="cat-chip"><i style="background:${colorOf(t.category)}"></i>${esc(t.category)}</span></td>
        <td class="num amt ${t.type}">${t.type === "income" ? "+" : "-"}${money(t.amount)}</td>
        <td class="num"><button class="del" data-id="${t.id}" type="button" aria-label="Delete ${esc(t.description)}">Delete</button></td>
      </tr>`).join("");
    lastAdded = null;
  }

  /* ---- monthly page ---- */
  function renderMonthly() {
    const M = STATE.monthly;
    upsert("monthly", "chMonthly", {
      type: "bar",
      data: {
        labels: M.map((m) => m.label),
        datasets: [
          { type: "bar", label: "Income", data: M.map((m) => m.income), backgroundColor: "#0B7A75", borderRadius: 5 },
          { type: "bar", label: "Spent", data: M.map((m) => m.expense), backgroundColor: "#F2A33A", borderRadius: 5 },
          { type: "line", label: "Saved", data: M.map((m) => m.savings), borderColor: "#6A5ACD", backgroundColor: "#6A5ACD", tension: 0.3, borderWidth: 2.5, pointRadius: 4 },
        ],
      },
      options: {
        maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
        scales: { x: { grid: { display: false } }, y: { ticks: { callback: axisMoney }, grid: { color: "#EEF0F5" } } },
        plugins: { legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 10 } },
                   tooltip: { callbacks: { label: (c) => ` ${c.dataset.label}: ${money(c.parsed.y)}` } } },
      },
    });

    const cats = [...new Set(M.flatMap((m) => Object.keys(m.categories)))];
    cats.sort((a, b) => M.reduce((s, m) => s + (m.categories[b] || 0), 0) - M.reduce((s, m) => s + (m.categories[a] || 0), 0));
    upsert("stack", "chStack", {
      type: "bar",
      data: {
        labels: M.map((m) => m.label),
        datasets: cats.map((c) => ({ label: c, data: M.map((m) => m.categories[c] || 0), backgroundColor: colorOf(c), borderWidth: 0 })),
      },
      options: {
        maintainAspectRatio: false,
        scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, ticks: { callback: axisMoney }, grid: { color: "#EEF0F5" } } },
        plugins: { legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 8, font: { size: 11 } } },
                   tooltip: { callbacks: { label: (c) => ` ${c.dataset.label}: ${money(c.parsed.y)}` } } },
      },
    });

    $("#monthBody").innerHTML = [...M].reverse().map((m) => `
      <tr class="click" data-month="${m.month}">
        <td><strong>${m.label}</strong></td>
        <td class="num">${money(m.income)}</td>
        <td class="num">${money(m.expense)}</td>
        <td class="num" style="color:${m.savings < 0 ? "var(--poppy)" : "inherit"}">${money(m.savings)}</td>
        <td class="num">${m.savings_rate === null ? "–" : pct(m.savings_rate)}</td>
        <td>${m.top_category ? `<span class="cat-chip"><i style="background:${colorOf(m.top_category)}"></i>${esc(m.top_category)}</span>` : "–"}</td>
        <td>${m.risk ? `<span class="badge ${m.risk.toLowerCase()}">${m.risk}</span>` : "–"}</td>
      </tr>`).join("");
  }

  /* ---- insights page ---- */
  function renderInsights() {
    const C = STATE.clusters;
    $("#clusterEmpty").hidden = C.length > 0;
    $("#chCluster").parentElement.hidden = C.length === 0;
    $("#clusterCards").innerHTML = C.map((c) => `
      <div class="cluster"><i style="background:${clusterColor(c.rank, C.length)}"></i>
        <div><strong>${esc(c.name)}</strong>
        <p>${c.count} purchases · average ${money(c.avg)} · ${money(c.total)} in total (${pct(c.share)} of spending). Mostly ${esc(c.top_category)}.</p></div>
      </div>`).join("");
    if (C.length) {
      upsert("cluster", "chCluster", {
        type: "scatter",
        data: {
          datasets: C.map((c) => ({
            label: c.name,
            data: STATE.points.filter((p) => p.c === c.rank),
            backgroundColor: clusterColor(c.rank, C.length) + "CC",
            pointRadius: 5, pointHoverRadius: 7,
          })),
        },
        options: {
          maintainAspectRatio: false, parsing: { xAxisKey: "x", yAxisKey: "y" },
          scales: {
            x: { title: { display: true, text: "Day of the month" }, min: 0, max: 32, grid: { color: "#EEF0F5" } },
            y: { title: { display: true, text: "Amount" }, ticks: { callback: axisMoney }, grid: { color: "#EEF0F5" } },
          },
          plugins: {
            legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 10 } },
            tooltip: { callbacks: { label: (c) => { const p = c.raw; return ` ${p.d} · ${p.cat} · ${money(p.y)} · ${p.date}`; } } },
          },
        },
      });
    }

    const r = STATE.risk, box = $("#riskBox");
    if (!r.probabilities) {
      box.innerHTML = '<p class="empty">Add expenses to get a risk rating.</p>';
      return;
    }
    box.innerHTML = `
      <div class="risk-big"><span class="badge ${r.label.toLowerCase()}">${r.label} risk</span>
        <span class="muted">for ${esc(r.month)} · ${pct(r.confidence)} confidence</span></div>
      ${["Low", "Medium", "High"].map((k) => `
        <div class="prob"><span>${k}</span><div class="track"><div class="fill ${k}" style="width:${r.probabilities[k] * 100}%"></div></div><span>${pct(r.probabilities[k])}</span></div>`).join("")}
      <p class="why-title">Why this rating</p>
      <ul class="why">${r.reasons.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
      <p class="muted small-note">The tree was trained on ${"1,800"} labelled examples from data/risk_training.csv and scores ${pct(r.model_accuracy)} on held-out tests.</p>`;
  }

  /* ---------------- add-transaction form ---------------- */
  const todayStr = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);

  function mountForm(host, afterSave) {
    const form = $("#txFormTpl").content.firstElementChild.cloneNode(true);
    host.innerHTML = "";
    host.appendChild(form);
    const catSel = form.elements.category, err = $(".form-error", form);

    function fillCategories() {
      const type = form.elements.type.value;
      const list = type === "income" ? STATE.meta.income_categories : STATE.meta.expense_categories;
      catSel.innerHTML = list.map((c) => `<option>${esc(c)}</option>`).join("");
    }
    form.elements.date.value = todayStr();
    fillCategories();
    $$('input[name="type"]', form).forEach((r) => r.addEventListener("change", fillCategories));

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      err.hidden = true;
      const body = {
        type: form.elements.type.value, amount: form.elements.amount.value, date: form.elements.date.value,
        category: catSel.value, description: form.elements.description.value,
      };
      try {
        const row = await api("/api/transactions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        form.elements.amount.value = "";
        form.elements.description.value = "";
        lastAdded = row.id;
        let note = "";
        const rowMonth = row.date.slice(0, 7);
        if (selectedMonth !== "all" && selectedMonth !== rowMonth) {
          selectedMonth = rowMonth;
          note = ` · showing ${new Date(row.date + "T00:00").toLocaleDateString("en-IN", { month: "long", year: "numeric" })}`;
        }
        const before = clientKpis();
        await loadAll();
        const after = clientKpis();
        const field = row.type === "income" ? "income" : "expense";
        const change = note ? "" : ` · ${row.type === "income" ? "Income" : "Spent"} ${money(before[field])} → ${money(after[field])}`;
        toast(`Saved ${row.type === "income" ? "+" : "-"}${money(row.amount)} · ${row.category}${change}${note}`);
        if (afterSave) afterSave();
      } catch (ex) {
        err.textContent = ex.message;
        err.hidden = false;
      }
    });
    return form;
  }

  /* ---------------- events ---------------- */
  function bind() {
    $("#monthSelect").addEventListener("change", (e) => { selectedMonth = e.target.value; loadAll(); });

    // dialog
    const dlg = $("#addDialog");
    let dialogForm = null;
    $("#openAdd").addEventListener("click", () => {
      dialogForm = mountForm($("#dialogFormHost"), () => dlg.close());
      dlg.showModal();
      dialogForm.elements.amount.focus();
    });
    $("#closeAdd").addEventListener("click", () => dlg.close());
    dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });

    // two-step delete (works in dashboard list and history table)
    document.addEventListener("click", async (e) => {
      const del = e.target.closest(".del");
      if (del) {
        if (!del.classList.contains("confirm")) {
          del.classList.add("confirm");
          del.textContent = "Confirm?";
          setTimeout(() => { if (del.isConnected) { del.classList.remove("confirm"); del.textContent = "Delete"; } }, 3000);
          return;
        }
        try {
          await api("/api/transactions/" + del.dataset.id, { method: "DELETE" });
          await loadAll();
          toast("Transaction deleted. Charts updated.");
        } catch (ex) { toast(ex.message, true); }
        return;
      }
      const row = e.target.closest("tr[data-month]");
      if (row) { selectedMonth = row.dataset.month; location.hash = "#dashboard"; loadAll(); }
    });

    // history filters
    ["fSearch", "fType", "fCat", "fMonth"].forEach((id) => $("#" + id).addEventListener("input", renderHistory));

    // clear all
    $("#clearAll").addEventListener("click", async () => {
      if (!confirm("Delete ALL transactions? Copy data/transactions.csv somewhere first if you want a backup.")) return;
      await api("/api/clear", { method: "POST" });
      selectedMonth = "latest";
      await loadAll();
      toast("All transactions cleared.");
    });

    // stay in sync if the CSV changed in another tab or file
    window.addEventListener("focus", () => loadAll(true).catch(() => {}));
    setInterval(() => { if (!document.hidden) loadAll(true).catch(() => {}); }, 3000);
  }

  /* ---------------- start ---------------- */
  (async function init() {
    bind();
    try {
      await loadAll();
      mountForm($("#inlineFormHost"));
    } catch (ex) {
      toast("Could not load data: " + ex.message, true);
    }
    showPage();
  })();
})();
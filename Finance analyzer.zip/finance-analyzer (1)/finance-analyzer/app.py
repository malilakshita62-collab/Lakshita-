"""
AI Personal Finance & Expense Pattern Analyzer
Flask backend - all data lives in CSV files inside the /data folder.
"""
import io
import math
import os
import threading
from datetime import datetime

import pandas as pd
from flask import Flask, jsonify, render_template, request, send_file

from ml_engine import (EXPENSE_CATEGORIES, INCOME_CATEGORIES, RiskModel,
                       build_analysis)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
TX_FILE = os.path.join(DATA_DIR, "transactions.csv")
TRAIN_FILE = os.path.join(DATA_DIR, "risk_training.csv")
COLUMNS = ["id", "date", "description", "category", "type", "amount"]

app = Flask(__name__)
LOCK = threading.RLock()
os.makedirs(DATA_DIR, exist_ok=True)
risk_model = RiskModel(TRAIN_FILE)          # Decision Tree is trained once at start-up


# ----------------------------------------------------------------------------
# CSV helpers
# ----------------------------------------------------------------------------
def read_tx():
    with LOCK:
        if not os.path.exists(TX_FILE):
            pd.DataFrame(columns=COLUMNS).to_csv(TX_FILE, index=False)
        try:
            df = pd.read_csv(TX_FILE)
        except pd.errors.EmptyDataError:
            df = pd.DataFrame(columns=COLUMNS)
    for c in COLUMNS:
        if c not in df.columns:
            df[c] = ""
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
    df = df.dropna(subset=["amount"])
    df["id"] = pd.to_numeric(df["id"], errors="coerce")
    missing = df["id"].isna()
    if missing.any():
        start = int(df["id"].max()) if df["id"].notna().any() else 0
        df.loc[missing, "id"] = range(start + 1, start + 1 + int(missing.sum()))
    df["id"] = df["id"].astype(int)
    df["description"] = df["description"].fillna("").astype(str)
    return df[COLUMNS].reset_index(drop=True)


def write_tx(df):
    with LOCK:
        tmp = TX_FILE + ".tmp"
        df.sort_values(["date", "id"])[COLUMNS].to_csv(tmp, index=False)
        try:
            os.replace(tmp, TX_FILE)
        except PermissionError:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise


def clean_row(d, strict=True):
    """Validate one transaction. Raises ValueError with a readable message."""
    t = str(d.get("type", "")).strip().lower()
    if t not in ("income", "expense"):
        raise ValueError("Type must be income or expense.")
    try:
        amount = float(d.get("amount"))
    except (TypeError, ValueError):
        raise ValueError("Amount must be a number.")
    if not math.isfinite(amount) or amount <= 0:
        raise ValueError("Amount must be greater than zero.")
    try:
        date = pd.to_datetime(str(d.get("date", "")).strip(), errors="raise").strftime("%Y-%m-%d")
    except Exception:
        raise ValueError("Enter a valid date (YYYY-MM-DD).")
    allowed = EXPENSE_CATEGORIES if t == "expense" else INCOME_CATEGORIES
    cat = str(d.get("category", "")).strip()
    if cat not in allowed:
        if strict:
            raise ValueError("Pick a category from the list.")
        cat = "Other" if t == "expense" else "Other Income"
    desc = str(d.get("description", "") or "").strip()[:80] or cat
    return {"date": date, "description": desc, "category": cat, "type": t,
            "amount": round(amount, 2)}


@app.errorhandler(Exception)
def api_error(e):
    if request.path.startswith("/api/"):
        if isinstance(e, PermissionError):
            return jsonify({"error": "Could not save. Close data/transactions.csv if it is open in Excel, then try again."}), 500
        return jsonify({"error": f"Server error: {e}"}), 500
    raise e


BUILD = "build 4"


@app.context_processor
def inject_version():
    """Changes whenever a static file changes, so the browser never runs stale JS/CSS."""
    stamp = 0
    for rel in ("static/js/app.js", "static/css/style.css"):
        try:
            stamp = max(stamp, int(os.path.getmtime(os.path.join(BASE_DIR, rel))))
        except OSError:
            pass
    return {"asset_v": stamp, "build": BUILD}


@app.after_request
def no_cache(resp):
    """Never let the browser reuse an old answer - the CSV can change any time."""
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store, max-age=0"
    return resp


@app.errorhandler(PermissionError)
def locked_file(_e):
    return jsonify({"error": "Could not save. Close data/transactions.csv if it is open in Excel, then try again."}), 500


@app.errorhandler(Exception)
def any_error(e):
    if request.path.startswith("/api/"):
        code = getattr(e, "code", 500)
        return jsonify({"error": str(e)}), code if isinstance(code, int) else 500
    raise e


# ----------------------------------------------------------------------------
# Pages & API
# ----------------------------------------------------------------------------
@app.route("/")
def index():
    # version number = last change time of the JS/CSS, so the browser never uses an old copy
    ver = int(max(os.path.getmtime(os.path.join(BASE_DIR, "static", "js", "app.js")),
                  os.path.getmtime(os.path.join(BASE_DIR, "static", "css", "style.css"))))
    return render_template("index.html", v=ver)


@app.after_request
def no_cache(resp):
    """Always send fresh data so dashboard numbers can never be stale."""
    resp.headers["Cache-Control"] = "no-store, max-age=0"
    return resp


@app.route("/api/state")
def api_state():
    """Everything the dashboard needs (KPIs, charts, ML results)."""
    return jsonify(build_analysis(read_tx(), request.args.get("month", "latest"), risk_model))


@app.route("/api/transactions", methods=["GET"])
def api_list():
    df = read_tx().sort_values(["date", "id"], ascending=False)
    return jsonify(df.to_dict(orient="records"))


@app.route("/api/transactions", methods=["POST"])
def api_add():
    try:
        row = clean_row(request.get_json(force=True, silent=True) or {})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    with LOCK:
        df = read_tx()
        row["id"] = int(df["id"].max()) + 1 if len(df) else 1
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
        write_tx(df)
    return jsonify(row), 201


@app.route("/api/transactions/<int:tx_id>", methods=["DELETE"])
def api_delete(tx_id):
    with LOCK:
        df = read_tx()
        if tx_id not in df["id"].values:
            return jsonify({"error": "Transaction not found."}), 404
        write_tx(df[df["id"] != tx_id])
    return jsonify({"deleted": tx_id})


@app.route("/api/export")
def api_export():
    buf = io.BytesIO(read_tx().sort_values(["date", "id"]).to_csv(index=False).encode("utf-8"))
    name = f"transactions_{datetime.now():%Y%m%d}.csv"
    return send_file(buf, mimetype="text/csv", as_attachment=True, download_name=name)


@app.route("/api/clear", methods=["POST"])
def api_clear():
    write_tx(pd.DataFrame(columns=COLUMNS))
    return jsonify({"ok": True})


if __name__ == "__main__":
    print("\n  Open http://127.0.0.1:5000 in your browser\n")
    app.run(host="127.0.0.1", port=5000, debug=True)
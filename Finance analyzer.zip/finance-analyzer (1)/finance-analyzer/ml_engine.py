"""
ml_engine.py
All analysis logic: monthly summaries, K-Means spending patterns,
Decision Tree risk rating and rule-based suggestions.
Data comes from a pandas DataFrame (loaded from CSV by app.py).
"""
import os
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

# ----------------------------------------------------------------------------
# Settings (change the currency symbol here if you like)
# ----------------------------------------------------------------------------
CURRENCY = "₹"

EXPENSE_CATEGORIES = [
    "Housing", "Groceries", "Dining", "Transport", "Utilities", "Health",
    "Shopping", "Entertainment", "Travel", "Education", "Subscriptions", "Other",
]
INCOME_CATEGORIES = ["Salary", "Freelance", "Investments", "Gift", "Other Income"]

# Categories treated as "non-essential" by the risk model and suggestions
DISCRETIONARY = {"Dining", "Shopping", "Entertainment", "Travel", "Subscriptions"}

RISK_FEATURES = ["expense_ratio", "top_share", "disc_share", "mom_change"]
FEATURE_LABELS = {
    "expense_ratio": "Spending vs income",
    "top_share": "Biggest category's share of spending",
    "disc_share": "Non-essential share of spending",
    "mom_change": "Change from previous month",
}


def money(x):
    return f"{CURRENCY}{x:,.0f}"


def pct(x):
    return f"{x * 100:.0f}%"


def r2(x):
    return round(float(x), 2)


# ----------------------------------------------------------------------------
# Decision Tree – risk model
# ----------------------------------------------------------------------------
def generate_risk_training(path, n=1800, seed=42):
    """Create a labelled training CSV (Low / Medium / High risk) for the tree."""
    rng = np.random.default_rng(seed)
    ratio = rng.uniform(0.3, 1.4, n)
    top = rng.uniform(0.2, 0.7, n)
    disc = rng.uniform(0.05, 0.7, n)
    mom = rng.uniform(-0.4, 0.6, n)
    score = 2.2 * ratio + 0.9 * disc + 0.5 * np.maximum(mom, 0) + 0.6 * top
    score += rng.normal(0, 0.08, n)
    label = np.where(score < 2.1, "Low", np.where(score < 2.65, "Medium", "High"))
    label = np.where(ratio >= 1.0, "High", label)
    df = pd.DataFrame({
        "expense_ratio": ratio.round(3), "top_share": top.round(3),
        "disc_share": disc.round(3), "mom_change": mom.round(3), "risk": label,
    })
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df.to_csv(path, index=False)
    return df


class RiskModel:
    def __init__(self, training_csv):
        if not os.path.exists(training_csv):
            generate_risk_training(training_csv)
        data = pd.read_csv(training_csv)
        X, y = data[RISK_FEATURES], data["risk"]
        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y)
        self.tree = DecisionTreeClassifier(
            max_depth=4, min_samples_leaf=15, random_state=42).fit(X_tr, y_tr)
        self.accuracy = float(self.tree.score(X_te, y_te))
        # final model uses all data
        self.tree.fit(X, y)

    def predict(self, feats):
        x = pd.DataFrame([feats])[RISK_FEATURES]
        label = str(self.tree.predict(x)[0])
        proba = self.tree.predict_proba(x)[0]
        probs = {str(c): r2(p) for c, p in zip(self.tree.classes_, proba)}
        # Explain the decision by following the path through the tree
        t = self.tree.tree_
        found = {}
        for nid in self.tree.decision_path(x).indices:
            if t.children_left[nid] == t.children_right[nid]:
                continue
            fi = t.feature[nid]
            name = RISK_FEATURES[fi]
            val, thr = float(x.iloc[0, fi]), float(t.threshold[nid])
            op = "≤" if val <= thr else ">"
            found[name] = f"{FEATURE_LABELS[name]} is {pct(val)} ({op} {pct(thr)})"
        reasons = list(found.values())  # one line per feature (tightest rule)
        return {
            "label": label,
            "confidence": probs.get(label, 0),
            "probabilities": {k: probs.get(k, 0) for k in ("Low", "Medium", "High")},
            "reasons": reasons,
            "features": {k: r2(v) for k, v in feats.items()},
            "model_accuracy": r2(self.accuracy),
        }


def month_features(mdf, prev_expense):
    exp = mdf[mdf["type"] == "expense"]
    inc = mdf[mdf["type"] == "income"]
    expense, income = float(exp["amount"].sum()), float(inc["amount"].sum())
    if expense <= 0:
        return None
    ratio = min(expense / income, 1.5) if income > 0 else 1.5
    by_cat = exp.groupby("category")["amount"].sum()
    top = float(by_cat.max() / expense)
    disc = float(by_cat[by_cat.index.isin(DISCRETIONARY)].sum() / expense)
    mom = 0.0
    if prev_expense and prev_expense > 0:
        mom = float(np.clip((expense - prev_expense) / prev_expense, -1, 1))
    return {"expense_ratio": ratio, "top_share": top, "disc_share": disc, "mom_change": mom}


# ----------------------------------------------------------------------------
# K-Means – spending patterns
# ----------------------------------------------------------------------------
CLUSTER_NAMES = {
    3: ["Everyday small spends", "Regular spends", "Big-ticket spends"],
    2: ["Everyday spends", "Big-ticket spends"],
}


def cluster_expenses(exp):
    n = len(exp)
    if n < 8:
        return [], []
    d = exp.copy()
    X = np.column_stack([
        np.log1p(d["amount"].values),
        d["date"].dt.weekday.values,
        d["date"].dt.day.values,
        d["category"].isin(DISCRETIONARY).astype(int).values,
    ]).astype(float)
    Xs = StandardScaler().fit_transform(X)
    Xs[:, 0] *= 2.5  # amount matters most
    k = min(3 if n >= 15 else 2, d["amount"].nunique())
    if k < 2:
        return [], []
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(Xs)
    d["cl"] = km.labels_
    order = d.groupby("cl")["amount"].mean().sort_values().index.tolist()
    d["rank"] = d["cl"].map({c: i for i, c in enumerate(order)})
    names = CLUSTER_NAMES[k]
    total = float(d["amount"].sum())
    summary = []
    for rank in range(k):
        g = d[d["rank"] == rank]
        top_cat = g.groupby("category")["amount"].sum().idxmax()
        summary.append({
            "rank": rank, "name": names[rank], "count": int(len(g)),
            "total": r2(g["amount"].sum()), "avg": r2(g["amount"].mean()),
            "min": r2(g["amount"].min()), "max": r2(g["amount"].max()),
            "share": r2(g["amount"].sum() / total), "top_category": top_cat,
        })
    pts = d.sort_values("date").tail(500)
    points = [{
        "x": int(r.date.day), "y": r2(r.amount), "c": int(r["rank"]),
        "d": r.description, "cat": r.category, "date": r.date.strftime("%d %b %Y"),
    } for _, r in pts.iterrows()]
    return summary, points


# ----------------------------------------------------------------------------
# Suggestions
# ----------------------------------------------------------------------------
CAT_LIMITS = {"Dining": 0.12, "Shopping": 0.12, "Entertainment": 0.08,
              "Subscriptions": 0.05, "Travel": 0.12}


def build_suggestions(income, expense, cats, clusters, risk):
    out = []

    def add(level, title, text):
        out.append({"level": level, "title": title, "text": text})

    if expense <= 0:
        add("info", "Add your first expenses",
            "Suggestions appear as soon as this period has some spending in it.")
        return out

    rate = (income - expense) / income if income > 0 else None
    if income <= 0:
        add("warn", "No income recorded",
            "Add your salary or other income so savings and risk can be measured properly.")
    elif rate < 0:
        add("alert", "You spent more than you earned",
            f"Spending is {money(expense - income)} above income. Start with the non-essential "
            "categories below and pause big purchases until the gap closes.")
    elif rate < 0.10:
        need = 0.20 * income - (income - expense)
        add("warn", "Savings are thin",
            f"You kept {pct(rate)} of your income. Aiming for 20% means finding about "
            f"{money(need)} in savings.")
    elif rate >= 0.20:
        add("good", "Healthy savings rate",
            f"You kept {pct(rate)} of your income. Moving the surplus into a fixed monthly "
            "investment keeps it from being spent.")

    for c in cats:
        name, share = c["category"], c["share"]
        if name in CAT_LIMITS and share > CAT_LIMITS[name]:
            add("warn", f"{name} is taking {pct(share)} of spending",
                f"That is {money(c['amount'])}. Trimming it by 20% would free {money(c['amount'] * 0.2)}.")
        if name == "Housing" and income > 0 and c["amount"] / income > 0.40:
            add("warn", "Housing is over 40% of income",
                f"Housing costs {money(c['amount'])}, {pct(c['amount'] / income)} of what you earn. "
                "Little room is left for savings; look at ways to lower or share this cost.")
        if (c.get("change") is not None and c["change"] > 0.25
                and c["amount"] > 0.03 * expense):
            add("warn", f"{name} rose {pct(c['change'])} from last month",
                f"It went from {money(c['prev'])} to {money(c['amount'])}. Check whether this was a one-off.")

    if clusters:
        big, small = clusters[-1], clusters[0]
        if big["share"] > 0.50 and big["count"] <= max(3, 0.15 * sum(c["count"] for c in clusters)):
            add("info", "A few large purchases drive your spending",
                f"{big['count']} big-ticket purchases make up {pct(big['share'])} of spending "
                f"(average {money(big['avg'])}). Plan for them ahead of time or spread them out.")
        total_count = sum(c["count"] for c in clusters)
        if small["count"] >= 0.45 * total_count and small["share"] >= 0.15:
            add("info", "Small purchases add up",
                f"{small['count']} small spends (average {money(small['avg'])}) cost you "
                f"{money(small['total'])} in total. A weekly cap can cut this without much pain.")

    if risk and risk.get("label") == "High":
        add("alert", "Risk level is High",
            "The Decision Tree flags this period as high risk. Build a buffer by lowering "
            "non-essential spending first.")
    elif risk and risk.get("label") == "Medium":
        add("warn", "Risk level is Medium",
            "You are close to the line. Keep an eye on non-essential spending for the rest of the month.")
    elif risk and risk.get("label") == "Low":
        add("good", "Risk level is Low",
            "Spending is well inside your income. Keep the same habits.")

    order = {"alert": 0, "warn": 1, "info": 2, "good": 3}
    out.sort(key=lambda s: order[s["level"]])
    return out[:8]


# ----------------------------------------------------------------------------
# Main entry – everything the dashboard needs in one call
# ----------------------------------------------------------------------------
def prepare(raw):
    df = raw.copy()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
    df = df.dropna(subset=["date", "amount"])
    df["month"] = df["date"].dt.strftime("%Y-%m")
    return df


def build_analysis(raw, month, model, today=None):
    today = pd.Timestamp(today or datetime.now()).normalize()
    df = prepare(raw)
    months = sorted(df["month"].unique().tolist()) if len(df) else []
    meta = {"currency": CURRENCY, "expense_categories": EXPENSE_CATEGORIES,
            "income_categories": INCOME_CATEGORIES}

    if not months:
        return {"meta": meta, "has_data": False, "months": [], "month": "all",
                "period_label": "No data yet",
                "kpis": {"income": 0, "expense": 0, "savings": 0, "savings_rate": None,
                         "count": 0, "avg_daily": 0, "days": 1, "prev": None},
                "categories": [], "monthly": [], "daily": {"labels": [], "values": [], "cumulative": [], "weekly": False},
                "clusters": [], "points": [], "risk": {"label": "No data"},
                "suggestions": build_suggestions(0, 0, [], [], None), "recent": []}

    if month in (None, "", "latest") or (month != "all" and month not in months):
        month = months[-1]

    # ---- monthly table (always all months) ----
    monthly, risk_by_month, prev_exp = [], {}, None
    for m in months:
        mdf = df[df["month"] == m]
        inc = float(mdf[mdf["type"] == "income"]["amount"].sum())
        exp = float(mdf[mdf["type"] == "expense"]["amount"].sum())
        feats = month_features(mdf, prev_exp)
        risk = model.predict(feats) if feats else None
        risk_by_month[m] = risk
        cats = mdf[mdf["type"] == "expense"].groupby("category")["amount"].sum()
        monthly.append({
            "month": m, "label": pd.Period(m).strftime("%b %Y"),
            "income": r2(inc), "expense": r2(exp), "savings": r2(inc - exp),
            "savings_rate": r2((inc - exp) / inc) if inc > 0 else None,
            "top_category": cats.idxmax() if len(cats) else None,
            "count": int(len(mdf)), "risk": risk["label"] if risk else None,
            "categories": {k: r2(v) for k, v in cats.items()},
        })
        if exp > 0:
            prev_exp = exp

    # ---- selected period ----
    pdf = df if month == "all" else df[df["month"] == month]
    exp_df = pdf[pdf["type"] == "expense"]
    income = float(pdf[pdf["type"] == "income"]["amount"].sum())
    expense = float(exp_df["amount"].sum())

    prev = None
    prev_cats = {}
    if month != "all":
        i = months.index(month)
        if i > 0:
            pm = monthly[i - 1]
            prev = {"label": pm["label"], "income": pm["income"], "expense": pm["expense"],
                    "savings": pm["savings"]}
            prev_cats = pm["categories"]

    # daily series
    if month != "all":
        start = pd.Period(month).start_time.normalize()
        end = pd.Period(month).end_time.normalize()
        end = max(start, min(end, max(today, pdf["date"].max().normalize())))
    else:
        start, end = pdf["date"].min().normalize(), pdf["date"].max().normalize()
    idx = pd.date_range(start, end)
    n_days = max(1, len(idx))
    daily = exp_df.groupby(exp_df["date"].dt.normalize())["amount"].sum().reindex(idx, fill_value=0.0)
    weekly = False
    if len(daily) > 92:
        weekly = True
        daily = daily.resample("W").sum()
    labels = [d.strftime("%d %b") for d in daily.index]
    values = [r2(v) for v in daily.values]
    cumulative = [r2(v) for v in daily.cumsum().values]

    # categories
    cat_sum = exp_df.groupby("category")["amount"].sum().sort_values(ascending=False)
    categories = []
    for name, amt in cat_sum.items():
        p = prev_cats.get(name)
        categories.append({
            "category": name, "amount": r2(amt),
            "share": r2(amt / expense) if expense > 0 else 0,
            "prev": p, "change": r2((amt - p) / p) if p else None,
        })

    clusters, points = cluster_expenses(exp_df)
    risk_month = month if month != "all" else months[-1]
    risk = risk_by_month.get(risk_month) or {"label": "No data"}
    risk = dict(risk, month=pd.Period(risk_month).strftime("%B %Y"))

    recent = df.sort_values(["date", "id"], ascending=False).head(7)
    recent = [{"id": int(r.id), "date": r.date.strftime("%Y-%m-%d"), "description": r.description,
               "category": r.category, "type": r.type, "amount": r2(r.amount)}
              for _, r in recent.iterrows()]

    return {
        "meta": meta, "has_data": True, "months": months, "month": month,
        "period_label": "All time" if month == "all" else pd.Period(month).strftime("%B %Y"),
        "kpis": {
            "income": r2(income), "expense": r2(expense), "savings": r2(income - expense),
            "savings_rate": r2((income - expense) / income) if income > 0 else None,
            "count": int(len(pdf)), "avg_daily": r2(expense / n_days), "days": int(n_days), "prev": prev,
        },
        "categories": categories, "monthly": monthly,
        "daily": {"labels": labels, "values": values, "cumulative": cumulative, "weekly": weekly},
        "clusters": clusters, "points": points, "risk": risk,
        "suggestions": build_suggestions(income, expense, categories, clusters, risk),
        "recent": recent,
    }